(function() {
  "use strict";

  // some boilerplate code for getting the basic context
  const createRouter = require('@arangodb/foxx/router');
  const router = createRouter();

  module.context.use(router);

  // these are the modules we need
  let db = require("@arangodb").db;
  let joi = require("joi");

  // provides a route HTTP GET /managersOf/<name of employee>
  router.get("/managersOf/:employee", function (req, res) {
    // run an AQL query on the database, using the employee 
    // name as a bind parameter
    let query = `
      FOR emp, edge, path IN 1..5 INBOUND 
	CONCAT('employees/', @employee) isManagerOf 
	RETURN { who: emp._key, levels: LENGTH(path.edges) }'
    `;

    // inject "employee" URL path parameter into the query
    // safely, using a bind parameter (prevents parameter
    // injection)
    let result = db._query(query, {
      employee: req.param("employee")
    }).toArray();

    // if employee not found or no managers present, then we
    // will respond with HTTP 404
    if (result.length === 0) {
      res.throw(404, "employee has no managers");
    }
    // otherwise return the query's full result as JSON
    res.json(result);
  })
  .pathParam("employee", joi.string().required(), "employee name")
  .summary("returns line managers of the employee")
  .response(200, 'will return a list of the managers')
  .error(404, 'employee has no managers');

  // add other routes as needed using
  // - router.get(...) for HTTP GET endpoints
  // - router.post(...) for HTTP POST endpoints
  // - router.put(...) for HTTP PUT endpoints
  // - router.patch(...) for HTTP PATCH endpoints
  // ...
}());
