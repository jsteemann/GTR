Employees demo Foxx service
===========================

Provides some basic REST API for employee operations.
It matches a demonstration app used in a presentation given at Gothenburg Tech Radar.

This app is intentionally kept very very simple. It is meant for demonstration purposes, 
and to show how easy it is to add a REST API for you data.

To use the app, you can upload the zip containing the app to an ArangoDB instance and 
mount it under `/employees`.

Once successfully uploaded, the app is accessible via the URL path `/employees/managersOf/<name of employee>`.
Note that the app will only work if there is a collection `employees` with some 
corresponding data. This collection is provided in the database dump too.

To issue an HTTP GET call to the app, you can use a browser or use cURL from the command-line, e.g.

```bash
curl -X GET --dump - --user "root:" http://127.0.0.1:8529/_db/_system/employees/managersOf/olaf`
```
(note: please adjust server connection details and login credentials as needed)

I recommend setting this app to "development" mode after installing, so any changes made
to the app's "employees.js" file are instantly picked up and visible.
